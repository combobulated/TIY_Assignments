//
//  WeatherDetailViewController.m
//  Forecaster
//
//  Created by Ben Gohlke on 3/22/15.
//  Copyright (c) 2015 The Iron Yard. All rights reserved.
//

#import "WeatherDetailViewController.h"

@interface WeatherDetailViewController ()

@property (weak, nonatomic) IBOutlet UILabel *summaryLabel;
@property (weak, nonatomic) IBOutlet UILabel *actualTemperatureLabel;
@property (weak, nonatomic) IBOutlet UILabel *apparentTemperatureLabel;
@property (weak, nonatomic) IBOutlet UILabel *dewPointLabel;
@property (weak, nonatomic) IBOutlet UILabel *humidityLabel;
@property (weak, nonatomic) IBOutlet UILabel *rainChanceLabel;
@property (weak, nonatomic) IBOutlet UILabel *windSpeedLabel;
@property (weak, nonatomic) IBOutlet UIImageView *iconImageView;

@end

@implementation WeatherDetailViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = self.city.name;
    self.summaryLabel.text = self.city.currentWeather.summary;
    self.actualTemperatureLabel.text = [self.city.currentWeather currentTemperature];
    self.iconImageView.image = [UIImage imageNamed:self.city.currentWeather.icon];
    self.apparentTemperatureLabel.text = [self.city.currentWeather feelsLikeTemperature];
    self.dewPointLabel.text = [self.city.currentWeather dewPointTemperature];
    self.humidityLabel.text = [self.city.currentWeather humidityPercentage];
    self.rainChanceLabel.text = [self.city.currentWeather chanceOfRain];
    self.windSpeedLabel.text = [self.city.currentWeather windSpeedMPH];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
