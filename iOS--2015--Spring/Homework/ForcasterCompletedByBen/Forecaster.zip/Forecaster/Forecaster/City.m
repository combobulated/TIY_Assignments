//
//  City.m
//  Forecaster
//
//  Created by Ben Gohlke on 3/21/15.
//  Copyright (c) 2015 The Iron Yard. All rights reserved.
//

#import "City.h"

@implementation City

- (instancetype)initWithZipCode:(NSString *)zip
{
    self = [super init];
    if (self)
    {
        _zipCode = zip;
    }
    return self;
}

- (instancetype)init
{
    return [self initWithZipCode:@"0"];
}

- (BOOL)parseCoordinateInfo:(NSDictionary *)mapsDictionary
{
    BOOL rc = NO;
    
    if (mapsDictionary)
    {
        rc = YES;
        NSArray *results = mapsDictionary[@"results"];
        NSDictionary *resultsDictionary = [results objectAtIndex:0];
        NSString *formatted_address = resultsDictionary[@"formatted_address"];
        NSArray *addressComponents = [formatted_address componentsSeparatedByString:@","];
        self.name = addressComponents[0];
        self.state = [addressComponents[1] componentsSeparatedByString:@" "][0];
        NSDictionary *geometry = resultsDictionary[@"geometry"];
        NSDictionary *location = geometry[@"location"];
        self.latitude = [location[@"lat"] doubleValue];
        self.longitude = [location[@"lng"] doubleValue];
    }
    
    return rc;
}

@end